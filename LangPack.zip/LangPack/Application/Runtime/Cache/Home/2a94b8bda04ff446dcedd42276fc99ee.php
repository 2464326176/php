<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <div>切换语言：<a href="?l=zh-cn">简体中文</a> | <a href="?l=ko-kr">韩语</a> | <a href="?l=en-us">英文</a> | <a href="?l=ja">日语</a></div>
        <div class="result"><?php echo (L("_Index")); ?></div>
    </body>
</html>