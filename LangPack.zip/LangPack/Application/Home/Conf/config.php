<?php
return array(
    //'配置项'=>'配置值'
    
    //语言包配置
    'LANG_SWITCH_ON' => true, // 开启语言包功能
    'LANG_AUTO_DETECT' => true, // 自动侦测语言 开启多语言功能后有效
    'LANG_LIST' => 'zh-cn,en-us,ja,ko-kr', //必须写可允许的语言列表
    'VAR_LANGUAGE' => 'l', // 默认语言切换变量
);