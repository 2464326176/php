/*
* @Author: Rosen
* @Date:   2017-05-09 16:48:55
* @Last Modified by:   Rosen
* @Last Modified time: 2017-05-17 21:20:30
*/

'use strict';

require('./layout.css');
require('node_modules/font-awesome/css/font-awesome.min.css');
require('./footer/index.css');
