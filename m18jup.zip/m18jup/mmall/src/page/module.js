/*
* @Author: Rosen
* @Date:   2017-05-09 16:47:03
* @Last Modified by:   Rosen
* @Last Modified time: 2017-05-09 16:47:14
*/

'use strict';
module.exports = {
    test: 1234
}