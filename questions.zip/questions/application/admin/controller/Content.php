<?php
namespace app\admin\controller;
use think\Controller;
Class Content extends Common


{
    public function index(){
        $sta_sub=\think\Request::instance()->param('sta_sub');
        if($sta_sub){
            
            $stage = \think\Db::query('select * from sxz_stage as a where a.stage_num=01');
            $this->assign('stage',$stage);
            return view();
        }else{
            $stage = \think\Db::query('select * from sxz_stage as a where a.stage_num=01');
            $this->assign('stage',$stage);
            return view();
        }
   
           
       
    }

// ajax_stage阶段
    public function ajax_stage(){
        if (\think\Request::instance()->isAjax()){
        $stage_num=\think\Request::instance()->param('stage_num');
            //dump($stage)
        $info = '<option>--请选择科目--</option>';
        $stage = \think\Db::query('select * from sxz_stage as a where a.stage_num='.$stage_num);
        foreach ($stage as $key => $value) {
            $info .= "<option value='{$value['sta_sub']}'>{$value['subject_name']}</option>";
        }
        return $info;

                   
        }else{
            // $this->error('错误');
        
        }
    }
// 版本
public function ajax_edition(){
    if (\think\Request::instance()->isAjax()){
    $sta_sub=\think\Request::instance()->param('sta_sub');
        //dump($stage)
    $info ='<option>--请选择版本--</option>';
    $ques ='<option>--请选择题型--</option>';
    $diff ='<option>--请选择难度--</option>';
    $top ='<option>--请选择题类--</option>';
    $sou ='<option>--请选择来源--</option>';
    $edition = \think\Db::query('select * from sxz_edition as a where a.sta_sub='.$sta_sub);
    $questions = \think\Db::query('select * from sxz_questions as a where a.sta_sub='.$sta_sub);
    $difficulty = \think\Db::query('select * from sxz_difficulty as a where a.sta_sub='.$sta_sub);
    $topic = \think\Db::query('select * from sxz_topic as a where a.sta_sub='.$sta_sub);
    $source = \think\Db::query('select * from sxz_source as a where a.sta_sub='.$sta_sub);
    
    foreach ($edition as $key => $value) {
        $info .= "<option value='{$value['edi_num']}'>{$value['edi_name']}</option>";
    }
    
    foreach ($questions as $key => $value) {
        $ques .= "<option value='{$value['ques_num']}'>{$value['ques_name']}</option>";
    }
    foreach ($difficulty as $key => $value) {
        $diff .= "<option value='{$value['diff_num']}'>{$value['diff_name']}</option>";
    }
    
    foreach ($topic as $key => $value) {
        $top .= "<option value='{$value['topic_num']}'>{$value['topic_name']}</option>";
    }
    
    foreach ($source as $key => $value) {
        $sou .= "<option value='{$value['source_num']}'>{$value['source_name']}</option>";
    }

    $data=["info"=>$info,"ques"=>$ques,"diff"=>$diff,"top"=>$top,"sou"=>$sou];
    // dump($data['info']);die;
    // return $data;
    return $data;
   
     
    }else{
        // $this->error('错误');
    
    }
}

// 年级
public function ajax_grade(){
    if (\think\Request::instance()->isAjax()){
    $edi_num=\think\Request::instance()->param('edi_num');
        //dump($stage)
    $info ='<option>--请选择年级--</option>';
    $grade = \think\Db::query('select * from sxz_grade as a where a.edi_num='.$edi_num);
    foreach ($grade as $key => $value) {
        if($value['sem_num']==7){
            $info .= "<option value='{$value['grade_num']}'>{$value['grade_name']}上</option>";
        }else{
            $info .= "<option value='{$value['grade_num']}'>{$value['grade_name']}下</option>";
        }
        
        
        
    }
    return $info;

               
    }else{
        // $this->error('错误');
    
    }
}
   // 章节
public function ajax_chapter(){
    if (\think\Request::instance()->isAjax()){
    $grade_num=\think\Request::instance()->param('grade_num');
        //dump($stage)
    $info ='<option>--请选择章节--</option>';
    $chapter = \think\Db::query('select * from sxz_chapter as a where a.grade_num='.$grade_num);
    foreach ($chapter as $key => $value) {
       
            $info .= "<option value='{$value['chap_num']}'>{$value['chapter_name']}</option>";     
    }
    return $info;

               
    }else{
        // $this->error('错误');
    
    }
}

   // 节
   public function ajax_section(){
    if (\think\Request::instance()->isAjax()){
    $chap_num=\think\Request::instance()->param('chap_num');
        //dump($stage)
    $info ='<option>--请选择节--</option>';
    $section = \think\Db::query('select * from sxz_section as a where a.chap_num='.$chap_num);
    foreach ($section as $key => $value) {
       
            $info .= "<option value='{$value['section_num']}'>{$value['section_name']}</option>";     
    }
    return $info;

               
    }else{
        // $this->error('错误');
    
    }
}
    
   // 知识点
   public function ajax_knowledge(){
    if (\think\Request::instance()->isAjax()){
    $section_num=\think\Request::instance()->param('section_num');
        //dump($stage)
    $info ='<option>--请选择知识点--</option>';
    $knowledge = \think\Db::query('select * from sxz_knowledge as a where a.section_num='.$section_num);
    foreach ($knowledge as $key => $value) {
       
            $info .= "<option value='{$value['know_num']}'>{$value['know_name']}</option>";     
    }
    return $info;

               
    }else{
        // $this->error('错误');
    
    }
}


// 添加题

public function add(){
    if(request()->isPost()){
        // echo "ok"; die;
        $sta_sub=\think\Request::instance()->param('sta_sub');
        $data=[
            'content'=>input('content'),
            'answers'=>input('answers'),
            'ques_num'=>input('ques_num'),
            'diff_num'=>input('diff_num'),
            'topic_num'=>input('topic_num'),
            'source_num'=>input('source_num'),
            'sta_sub'=>input('sta_sub'),
            'edi_num'=>input('edi_num'),
            'grade_num'=>input('grade_num'),
            'chap_num'=>input('chap_num'),
            'section_num'=>input('section_num'),
            'know_num'=>input('know_num'),
        ];

        
        // dump($data);die;
            $content= \think\Db::name('content')->insert($data);
            if($content){
                return $this->success('添加成功',url('Content/index?sta_sub='.$sta_sub));
            }else{
            return $this->error('添加失败');
            }
       
    }else{

        return $this->error('参数错误');
    }







}
    
             





}