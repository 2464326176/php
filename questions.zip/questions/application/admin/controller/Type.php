<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\Questions;
use app\admin\model\Difficulty;
use app\admin\model\Topic;
use app\admin\model\Source;
Class Type extends Common
{
// 首页
    public function index(){
        
        $stage= \think\Db::query('select * from sxz_stage as a where a.stage_num=01');
       
        
        // $data = \think\Db::query('select * from sxz_stage as a,sxz_edition as b,sxz_grade as c where a.sta_sub=b.sta_sub and b.edi_num=c.edi_num and a.stage_num=01');
        // dump($data);die;
        


         $this->assign('stage',$stage);
        // $this->assign('data',$data);
        return view();
    }
// 题型
    public function questions(){
        if(request()->isGet()){
            $id=\think\Request::instance()->param('id');
            $stage= \think\Db::query('select * from sxz_stage as a where a.id='.$id);
            $questions= \think\Db::query('select * from sxz_questions');
        $this->assign('stage',$stage);
        $this->assign('questions',$questions);
        return view();
            }
        }

        public function questionsadd(){

            if(request()->isPost()){
                $sta_sub=\think\Request::instance()->param('sta_sub');
                $stage=\think\Db::query('select * from sxz_stage as a where a.sta_sub='.$sta_sub);

                $questions=new Questions();
                $ques_num=$questions->ques_num();
                $ques_num=$ques_num[0]['max(ques_num)'];
                $ques_num=$ques_num+1;
                // dump($ques_num);die;

                 $data=[
                    'sta_sub'=>input('sta_sub'),
                    'ques_name'=>input('ques_name'),
                    'ques_num'=>$ques_num,
                ];
                // dump($data);die;
                $questions=db('questions')->insert($data);
                // dump($questions);die;
                if($questions){
                    $this->success('添加成功',url('Type/questions?id='.$stage[0]['id']));
                }else{
                    $this->error('添加失败');
                }


          
        }
    }
    // 修改

    public function questionsedit(){
        if(request()->isPost()){
           
            $id=\think\Request::instance()->param('id');
            
           
            // dump($id);die;
            $questions=\think\Db::query('select * from sxz_questions where id='.$id);
            // dump($knowledge);die;

            $sta_sub=$questions[0]['sta_sub'];
            $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
            // dump($section);die;
            $data=[

                'ques_name'=>input('ques_name'),
            ];  

            $questions=db('questions')->where('id',$id)->update($data);                                       
            if($questions){
                $this->success('修改成功',url('Type/questions?id='.$stage[0]['id']));
            }else{
                $this->error('修改失败');
            }

        }
    }
    // 删除
    public function questionsdel(){

        if(request()->isGet()){
            
             $id=\think\Request::instance()->param('id');
            //  dump($id);die;

             $questions=\think\Db::query('select * from sxz_questions where id='.$id);
             // dump($knowledge);die;
             $sta_sub=$questions[0]['sta_sub'];
             $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
             // dump($section);die;
             $questions=db('questions')->where('id',$id)->delete();

             if($questions){
                 $this->success('删除成功',url('Type/questions?id='.$stage[0]['id']));
             }else{
                 $this->error('删除失败');
             }
        }
    }
// 难度
    public function difficulty(){
        if(request()->isGet()){
            $id=\think\Request::instance()->param('id');
            $stage= \think\Db::query('select * from sxz_stage as a where a.id='.$id);
            $difficulty= \think\Db::query('select * from sxz_difficulty');
        $this->assign('stage',$stage);
        $this->assign('difficulty',$difficulty);
        return view();
            }
        }
        // 添加
        public function difficultyadd(){
            
                        if(request()->isPost()){
                            $sta_sub=\think\Request::instance()->param('sta_sub');
                            $stage=\think\Db::query('select * from sxz_stage as a where a.sta_sub='.$sta_sub);
            
                            $difficulty=new Difficulty();
                            $diff_num=$difficulty->diff_num();
                            $diff_num=$diff_num[0]['max(diff_num)'];
                            $diff_num=$diff_num+1;
                            // dump($ques_num);die;
            
                             $data=[
                                'sta_sub'=>input('sta_sub'),
                                'diff_name'=>input('diff_name'),
                                'diff_num'=>$diff_num,
                            ];
                            // dump($data);die;
                            $difficulty=db('difficulty')->insert($data);
                            // dump($difficulty);die;
                            if($difficulty){
                                $this->success('添加成功',url('Type/difficulty?id='.$stage[0]['id']));
                            }else{
                                $this->error('添加失败');
                            }
            
            
                      
                    }
                }
                // 修改
            
                public function difficultyedit(){
                    if(request()->isPost()){
                       
                        $id=\think\Request::instance()->param('id');
                        
                       
                        // dump($id);die;
                        $difficulty=\think\Db::query('select * from sxz_difficulty where id='.$id);
                        // dump($knowledge);die;
                        // dump($difficulty);die;
                        $sta_sub=$difficulty[0]['sta_sub'];
                        $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
                        // dump($section);die;
                        $data=[
            
                            'diff_name'=>input('diff_name'),
                        ];  
            
                        $difficulty=db('difficulty')->where('id',$id)->update($data);                                       
                        if($difficulty){
                            $this->success('修改成功',url('Type/difficulty?id='.$stage[0]['id']));
                        }else{
                            $this->error('修改失败');
                        }
            
                    }
                }
                // 删除
                public function difficultydel(){
            
                    if(request()->isGet()){
                        
                         $id=\think\Request::instance()->param('id');
                        //  dump($id);die;
            
                         $difficulty=\think\Db::query('select * from sxz_difficulty where id='.$id);
                         // dump($knowledge);die;
                         $sta_sub=$difficulty[0]['sta_sub'];
                         $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
                         // dump($section);die;
                         $difficulty=db('difficulty')->where('id',$id)->delete();
            
                         if($difficulty){
                             $this->success('删除成功',url('Type/difficulty?id='.$stage[0]['id']));
                         }else{
                             $this->error('删除失败');
                         }
                    }
                }



// 题类
   
   public function topic(){
    if(request()->isGet()){
        $id=\think\Request::instance()->param('id');
        $stage= \think\Db::query('select * from sxz_stage as a where a.id='.$id);
        $topic= \think\Db::query('select * from sxz_topic');
    $this->assign('stage',$stage);
    $this->assign('topic',$topic);
    return view();
        }
    }
    // 添加
    public function topicadd(){
        
                    if(request()->isPost()){
                        $sta_sub=\think\Request::instance()->param('sta_sub');
                        $stage=\think\Db::query('select * from sxz_stage as a where a.sta_sub='.$sta_sub);
        
                        $topic=new Topic();
                        $topic_num=$topic->topic_num();
                        $topic_num=$topic_num[0]['max(topic_num)'];
                        $topic_num=$topic_num+1;
                        // dump($ques_num);die;
        
                         $data=[
                            'sta_sub'=>input('sta_sub'),
                            'topic_name'=>input('topic_name'),
                            'topic_num'=>$topic_num,
                        ];
                        // dump($data);die;
                        $topic=db('topic')->insert($data);
                        // dump($difficulty);die;
                        if($topic){
                            $this->success('添加成功',url('Type/topic?id='.$stage[0]['id']));
                        }else{
                            $this->error('添加失败');
                        }
        
        
                  
                }
            }
            // 修改
        
            public function topicedit(){
                if(request()->isPost()){
                   
                    $id=\think\Request::instance()->param('id');
                    
                   
                    // dump($id);die;
                    $topic=\think\Db::query('select * from sxz_topic where id='.$id);
                    // dump($knowledge);die;
                    // dump($difficulty);die;
                    $sta_sub=$topic[0]['sta_sub'];
                    $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
                    // dump($section);die;
                    $data=[
        
                        'topic_name'=>input('topic_name'),
                    ];  
        
                    $topic=db('topic')->where('id',$id)->update($data);                                       
                    if($topic){
                        $this->success('修改成功',url('Type/topic?id='.$stage[0]['id']));
                    }else{
                        $this->error('修改失败');
                    }
        
                }
            }
            // 删除
            public function topicdel(){
        
                if(request()->isGet()){
                    
                     $id=\think\Request::instance()->param('id');
                    //  dump($id);die;
        
                     $topic=\think\Db::query('select * from sxz_topic where id='.$id);
                     // dump($knowledge);die;
                     $sta_sub=$topic[0]['sta_sub'];
                     $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
                     // dump($section);die;
                     $topic=db('topic')->where('id',$id)->delete();
        
                     if($topic){
                         $this->success('删除成功',url('Type/topic?id='.$stage[0]['id']));
                     }else{
                         $this->error('删除失败');
                     }
                }
            }




// 来源
public function source(){
    if(request()->isGet()){
        $id=\think\Request::instance()->param('id');
        $stage= \think\Db::query('select * from sxz_stage as a where a.id='.$id);
        $source= \think\Db::query('select * from sxz_source');
    $this->assign('stage',$stage);
    $this->assign('source',$source);
    return view();
        }
    }
    // 添加
    public function sourceadd(){
        
                    if(request()->isPost()){
                        $sta_sub=\think\Request::instance()->param('sta_sub');
                        $stage=\think\Db::query('select * from sxz_stage as a where a.sta_sub='.$sta_sub);
        
                        $source=new Source();
                        $source_num=$source->source_num();
                        $source_num=$source_num[0]['max(source_num)'];
                        $source_num=$source_num+1;
                        // dump($ques_num);die;
        
                         $data=[
                            'sta_sub'=>input('sta_sub'),
                            'source_name'=>input('source_name'),
                            'source_num'=>$source_num,
                        ];
                        // dump($data);die;
                        $source=db('source')->insert($data);
                        // dump($difficulty);die;
                        if($source){
                            $this->success('添加成功',url('Type/source?id='.$stage[0]['id']));
                        }else{
                            $this->error('添加失败');
                        }
        
        
                  
                }
            }
            // 修改
        
            public function sourceedit(){
                if(request()->isPost()){
                   
                    $id=\think\Request::instance()->param('id');
                    
                   
                    // dump($id);die;
                    $source=\think\Db::query('select * from sxz_source where id='.$id);
                    // dump($knowledge);die;
                    // dump($difficulty);die;
                    $sta_sub=$source[0]['sta_sub'];
                    $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
                    // dump($section);die;
                    $data=[
        
                        'source_name'=>input('source_name'),
                    ];  
        
                    $source=db('source')->where('id',$id)->update($data);                                       
                    if($source){
                        $this->success('修改成功',url('Type/source?id='.$stage[0]['id']));
                    }else{
                        $this->error('修改失败');
                    }
        
                }
            }
            // 删除
            public function sourcedel(){
        
                if(request()->isGet()){
                    
                     $id=\think\Request::instance()->param('id');
                    //  dump($id);die;
        
                     $source=\think\Db::query('select * from sxz_source where id='.$id);
                     // dump($knowledge);die;
                     $sta_sub=$source[0]['sta_sub'];
                     $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
                     // dump($section);die;
                     $source=db('source')->where('id',$id)->delete();
        
                     if($source){
                         $this->success('删除成功',url('Type/source?id='.$stage[0]['id']));
                     }else{
                         $this->error('删除失败');
                     }
                }
            }
















}