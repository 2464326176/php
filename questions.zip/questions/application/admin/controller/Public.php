<?php
namespace app\admin\controller;
use think\Controller;
Class public extends Controller
{
    public function index()
    {
        return $this->fetch();
    }

    public function header()
    {
        return $this->fetch();
    }
    public function left()
    {
        return $this->fetch();
    }

    public function footer()
    {
        return $this->fetch();
    }
    
    public function tool()
    {
        return $this->fetch();
    }
    
}

