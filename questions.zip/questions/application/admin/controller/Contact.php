<?php
namespace app\admin\controller;
use think\Controller;
Class Contact extends Common
{
    public function index(){
        if(request()->isPost()){
            $id=\think\Request::instance()->param('id');
            // dump($id);die;           
             $data=[
                'address'=>input('address'),
                'offphone'=>input('offphone'),
                'qq'=>input('qq'),
                'email'=>input('email'),            
            ];
            // dump($data);die;
            $data=db('contact')->where('id',$id)->update($data);
             
            if($data){
                $this->success('修改成功',url('Contact/index'));
            }else{
                $this->error('修改失败');
            }
     
        }else{ 

            $data= \think\Db::name('contact')->select();
            $this->assign('data',$data);
            return view();

        }

    }










}