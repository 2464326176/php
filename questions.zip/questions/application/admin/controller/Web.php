<?php
namespace app\admin\controller;
use think\Controller;
Class Web extends Common
{
    public function index(){
        if(request()->isPost()){
            $id=\think\Request::instance()->param('id');
            // dump($id);die;
             $data=[
                'copyright'=>input('copyright'),
                'switch'=>input('switch'),
                'switchshow'=>input('switchshow'),
            ];
            // dump($data);die;
             $data=db('webconfig')->where('id',$id)->update($data);
            if($data){
                $this->success('修改成功',url('Web/index'));
            }else{
                $this->error('修改失败');
            }
     
        }else{
             
            $data= \think\Db::name('webconfig')->select();
            $this->assign('data',$data);
            return view();

        }
        
    }


}