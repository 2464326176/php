<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\Admin;
class Login extends Controller
{
    public function index()
    {
        if(request()->isPost()){
            
            // $this->check(input('code'));
        	$admin=new Admin();
        	$num=$admin->login(input('post.'));
            // dump($num);die;
        	if($num==1){
        		$this->error('用户不存在！');
        	}
        	if($num==2){
        		$this->success('登录成功！',url('Index/index'));
        	}
        	if($num==3){
        		$this->error('密码错误！');
            }
            if($num==4){
        		$this->error('管理员状态未审核 请联系超级管理员！');
        	}
        	return;
        }
        
        return view();
    }


    // 验证码检测
    public function check($code='')
    {
        if (!captcha_check($code)) {
            $this->error('验证码错误');
        } else {
            return true;
        }
    }
     public function logout(){
        session(null); 
        $this->success('退出系统成功！',url('Login/index'));
    }


}
