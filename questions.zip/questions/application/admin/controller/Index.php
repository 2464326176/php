<?php
namespace app\admin\controller;
use think\Controller;
Class Index extends Common
{
    public function index()
    {
        return $this->fetch();
    }
    public function left()
    {
        return $this->fetch();
    }
    public function dh()
    {
        return $this->fetch();
    }
    public function wave()
    {
        return $this->fetch();
    }
    
}

