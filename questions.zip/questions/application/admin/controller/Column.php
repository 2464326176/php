<?php
namespace app\admin\controller;
use think\Controller;
use app\admin\model\Stage;
use app\admin\model\Edition;
use app\admin\model\Grade;
use app\admin\model\Chapter;
use app\admin\model\Section;
use app\admin\model\Knowledge;
Class Column extends Common
{
    
// 题库设计管理首页
    public function index(){

        $subject = \think\Db::query('select * from sxz_subject order by id');

        $this->assign('subject',$subject);
        return view();
    }


// 阶段科目管理
public function stage(){

            $id=\think\Request::instance()->param('id');
            if($id){
                // dump('ok');die;
                $stage = \think\Db::query('select * from sxz_stage where id='.$id);
                $this->assign('stage',$stage);
                return view();
            }else{
                // dump('123');die;
                $stage = \think\Db::query('select * from sxz_stage order by id ');
                $this->assign('stage',$stage);
                return view();
            }
           
 
        }
        // 添加
        public function stageadd(){
            if(request()->isPost()){
               
                $stage=new Stage();
                $sta_sub=$stage->sta_sub();
                $sta_sub=$sta_sub[0]['max(sta_sub)'];
                $sta_sub=$sta_sub+1;
                // dump($sta_sub);die;

                 $data=[
                    'stage_num'=>input('stage_num'),
                    'subject_name'=>input('subject_name'),
                    'sta_sub'=> $sta_sub,
                ];
                // dump($data);die;
                $stage=db('stage')->insert($data);
                // 

             
                if($stage ){
                    $this->success('添加成功',url('Column/stage'));
                }else{
                    $this->error('添加失败');
                }
         
            }
                }

                    // 修改
        public function stageedit(){
            if(request()->isPost()){
                $id=\think\Request::instance()->param('id');
                
               
                $data=[
                    'subject_name'=>input('subject_name'),
                ];  
                // dump($data);die;

                $stage=db('stage')->where('id',$id)->update($data);   
                                                 
                if($stage){
                    $this->success('修改成功',url('Column/stage'));
                }else{
                    $this->error('修改失败');
                }
                                       
            }      
            }

             // 删除
             public function stagedel(){
                if(request()->isGet()){
                    $id=\think\Request::instance()->param('id');
                    $stage=\think\Db::query('select * from sxz_stage where id='.$id); 
                    $sta_sub=$stage[0]['sta_sub'];
                    $edition=\think\Db::query('select * from sxz_edition where sta_sub='.$sta_sub);

                    $edi_num=$edition[0]['edi_num'];

                    $grade=\think\Db::query('select * from sxz_grade where edi_num='.$edi_num);

                    $grade_num=$grade[0]['grade_num'];

                    $chapter=\think\Db::query('select * from sxz_chapter where grade_num='.$grade_num);
                    $chap_num=$chapter[0]['chap_num'];

                    $section=\think\Db::query('select * from sxz_section where chap_num='.$chap_num);
                    $section_num=$section[0]['section_num'];

                    $stage=db('stage')->where('id',$id)->delete();
                    $edition=db('edition')->where('sta_sub',$sta_sub)->delete();
                    $grade=db('grade')->where('edi_num',$edi_num)->delete();
                    $chapter=db('chapter')->where('grade_num',$grade_num)->delete();
                    $section=db('section')->where('chap_num',$chap_num)->delete();
                    $knowledge=db('knowledge')->where('section_num',$section_num)->delete();
                    if($grade){
                        $this->success('删除成功',url('Column/stage'));
                    }else{
                        $this->error('删除失败');
                    }
             
                    
                }
            
                }  

                
// 版本
    public function edition(){

        if(request()->isGet()){
            $id=\think\Request::instance()->param('id');
            //dump($id);die;
            $stage = \think\Db::query('select * from sxz_stage where id='.$id);
            $edition = \think\Db::query('select * from sxz_edition where sta_sub='.$stage[0]['sta_sub']);
            // dump($edition);die;
            $this->assign('stage',$stage);
            $this->assign('edition',$edition);
            return view();
     
        }


        }
        // 添加
        public function ediadd(){
            if(request()->isPost()){
                $sta_sub=\think\Request::instance()->param('sta_sub');

                $edi_num=new Edition();
                $edi_num=$edi_num->edi_num();
                $edi_num=$edi_num[0]['max(edi_num)'];
                $edi_num=$edi_num+1;
                // dump($edi_num);die;

                $data=[
                    'sta_sub'=>input('sta_sub'),
                    'edi_name'=>input('edi_name'),
                    'edi_num'=>$edi_num,
                ];
                // dump($data);die;
                $edition=db('edition')->insert($data);
                // 
                $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
                if($edition ){
                    $this->success('添加成功',url('Column/edition?id='.$stage[0]['id']));
                }else{
                    $this->error('添加失败');
                }
            }
            }

                  // 修改
        public function editionedit(){
            if(request()->isPost()){
                $id=\think\Request::instance()->param('id');
                // dump($id);die;
                $edition=\think\Db::query('select * from sxz_edition where id='.$id);
                // dump($knowledge);die;

                $sta_sub=$edition[0]['sta_sub'];
                $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);
                // dump($section);die;
                $data=[
                    'edi_name'=>input('edi_name'),
                ];                                                                       
                $edition=db('edition')->where('id',$id)->update($data);                                       
                if($edition){
                    $this->success('修改成功',url('Column/edition?id='.$stage[0]['id']));
                }else{
                    $this->error('修改失败');
                }
                                       
            }
        
            }

              // 删除
              public function editiondel(){
                if(request()->isGet()){
                    $id=\think\Request::instance()->param('id');

                    $edition=\think\Db::query('select * from sxz_edition where id='.$id); 
                    

                    $sta_sub=$edition[0]['sta_sub'];
                    $edi_num=$edition[0]['edi_num'];
                    // dump($edi_num);die;
                    $stage=\think\Db::query('select * from sxz_stage where sta_sub='.$sta_sub);

                    $grade=\think\Db::query('select * from sxz_grade where edi_num='.$edi_num);
                    // dump($grade);die;
                    $grade_num=$grade[0]['grade_num'];

                    $chapter=\think\Db::query('select * from sxz_chapter where grade_num='.$grade_num);
                    $chap_num=$chapter[0]['chap_num'];

                    $section=\think\Db::query('select * from sxz_section where chap_num='.$chap_num);
                    $section_num=$section[0]['section_num'];
                    $edition=db('edition')->where('id',$id)->delete();
                    $grade=db('grade')->where('edi_num',$edi_num)->delete();
                    $chapter=db('chapter')->where('grade_num',$grade_num)->delete();
                    $section=db('section')->where('chap_num',$chap_num)->delete();
                    $knowledge=db('knowledge')->where('section_num',$section_num)->delete();
                    if($grade){
                        $this->success('删除成功',url('Column/edition?id='.$stage[0]['id']));
                    }else{
                        $this->error('删除失败');
                    }
             
                    
                }
            
                }  
// 年级

    public function grade(){
        if(request()->isGet()){
            
            $id=\think\Request::instance()->param('id');
            $edition = \think\Db::query('select * from sxz_edition where id='.$id);
            $stage = \think\Db::query('select * from sxz_stage where sta_sub='.$edition[0]['sta_sub']);
            // dump($stage);
            // dump($edition);die;
            // dump($edition[0]['edi_num']);die;
            $grade = \think\Db::query('select * from sxz_grade where edi_num='.$edition[0]['edi_num']);
            // dump($grade);
            $this->assign('grade',$grade);
            $this->assign('edition',$edition);
            $this->assign('stage',$stage);
            return view();
        }else{
             
        }

    }

      // 添加
      public function gradeadd(){
        if(request()->isPost()){
            $edi_num=\think\Request::instance()->param('edi_num');
            $grade_num=new Grade();
            $grade_num=$grade_num->grade_num();
            
            $grade_num=$grade_num[0]['max(grade_num)'];
            $grade_num=$grade_num+1;
            // dump($grade_num);die;

            $data=[
                'sem_num'=>input('sem_num'),
                'edi_num'=>input('edi_num'),
                'grade_name'=>input('grade_name'),
                'grade_num'=>$grade_num,
            ];
            // dump($data);die;
            $grade=db('grade')->insert($data);
            // 
            $edition=\think\Db::query('select * from sxz_edition where edi_num='.$edi_num);
            if($grade ){
                $this->success('添加成功',url('Column/grade?id='.$edition[0]['id']));
            }else{
                $this->error('添加失败');
            }
     
            
        }
    
        }
        // 修改
        public function gradeedit(){
            if(request()->isPost()){
                $id=\think\Request::instance()->param('id');
                // dump($id);die;
                $grade=\think\Db::query('select * from sxz_grade where id='.$id);
                // dump($knowledge);die;

                $edi_num=$grade[0]['edi_num'];
                $edition=\think\Db::query('select * from sxz_edition where edi_num='.$edi_num);
                // dump($section);die;
                $data=[
                    'grade_name'=>input('grade_name'),
                    'sem_num'=>input('sem_num'),

                ];                                                                       
                $grade=db('grade')->where('id',$id)->update($data);                                       
                if($grade){
                    $this->success('修改成功',url('Column/grade?id='.$edition[0]['id']));
                }else{
                    $this->error('修改失败');
                }
                                       
            }
        
            }

                     // 删除
                     public function gradedel(){
                        if(request()->isGet()){
                            $id=\think\Request::instance()->param('id');
                            
                            $grade=\think\Db::query('select * from sxz_grade where id='.$id);

                            $grade_num=$grade[0]['grade_num'];
                            $edi_num=$grade[0]['edi_num'];

                            $edition=\think\Db::query('select * from sxz_edition where edi_num='.$edi_num);

                            $chapter=\think\Db::query('select * from sxz_chapter where grade_num='.$grade_num);
                            $chap_num=$chapter[0]['chap_num'];

                            $section=\think\Db::query('select * from sxz_section where chap_num='.$chap_num);
                            $section_num=$section[0]['section_num'];
                            
                            $grade=db('grade')->where('id',$id)->delete();
                            $chapter=db('chapter')->where('grade_num',$grade_num)->delete();
                            $section=db('section')->where('chap_num',$chap_num)->delete();
                            $knowledge=db('knowledge')->where('section_num',$section_num)->delete();
                            if($grade){
                                $this->success('删除成功',url('Column/grade?id='.$edition[0]['id']));
                            }else{
                                $this->error('删除失败');
                            }
                     
                            
                        }
                    
                        }                   
    
   
            // 章节
            public function chapter(){

                if(request()->isGet()){
                    $id=\think\Request::instance()->param('id');
                    // dump($id);die;
                    $grade = \think\Db::query('select * from sxz_grade where id='.$id);
                    // dump($grade);die;
                    $edition = \think\Db::query('select * from sxz_edition where edi_num='.$grade[0]['edi_num']);
                    // dump($edition);die;
                    $stage = \think\Db::query('select * from sxz_stage where sta_sub='.$edition[0]['sta_sub']);
                    // dump($stage);die;
                    $chapter=\think\Db::query('select * from sxz_chapter where grade_num='.$grade[0]['grade_num']);
                    // dump($edition);die;
                    $this->assign('chapter',$chapter);
                    $this->assign('grade',$grade);
                    $this->assign('stage',$stage);
                    $this->assign('edition',$edition);
                    return view();
             
                }



            }

             // 添加
        public function chapteradd(){
           
            if(request()->isPost()){
                // dump('ok');die;
                $grade_num=\think\Request::instance()->param('grade_num');
                // dump($grade_num);die;
                $chap_num=new Chapter();
                $chap_num=$chap_num->chap_num();
                
                $chap_num=$chap_num[0]['max(chap_num)'];
                $chap_num=$chap_num+1;
                // dump($chap_num);die;

                $data=[
                    'grade_num'=>input('grade_num'),
                    'chapter_name'=>input('chapter_name'),
                    'chap_num'=>$chap_num,
                ];
                // dump($data);die;
                $chapter=db('chapter')->insert($data);
                // 
                $grade=\think\Db::query('select * from sxz_grade where grade_num='.$grade_num);
                if($chapter ){
                    $this->success('添加成功',url('Column/chapter?id='.$grade[0]['id']));
                }else{
                    $this->error('添加失败');
                }
         
                
            }
        
            }

             // 修改
             public function chapteredit(){
                if(request()->isPost()){
                    $id=\think\Request::instance()->param('id');
                    // dump($id);die;
                    $chapter=\think\Db::query('select * from sxz_chapter where id='.$id);
                    // dump($knowledge);die;

                    $grade_num=$chapter[0]['grade_num'];
                    $grade=\think\Db::query('select * from sxz_grade where grade_num='.$grade_num);
                    // dump($section);die;
                    $data=[
                        'chapter_name'=>input('chapter_name'),
                    ];                                                                       
                    $chapter=db('chapter')->where('id',$id)->update($data);                                       
                    if($chapter ){
                        $this->success('修改成功',url('Column/chapter?id='.$grade[0]['id']));
                    }else{
                        $this->error('修改失败');
                    }
                                           
                }
            
                }

                     // 删除
                     public function chapterdel(){
                        if(request()->isGet()){
                            $id=\think\Request::instance()->param('id');
                            
                            $chapter=\think\Db::query('select * from sxz_chapter where id='.$id);
                            
                            $grade_num=$chapter[0]['grade_num'];
                            $chap_num=$chapter[0]['chap_num'];
                            $grade=\think\Db::query('select * from sxz_grade where grade_num='.$grade_num);
                            
                            $section=\think\Db::query('select * from sxz_section where chap_num='.$chap_num);

                            $section_num=$section[0]['section_num'];

                            $chapter=db('chapter')->where('id',$id)->delete();
                            $section=db('section')->where('chap_num',$chap_num)->delete();
                            $knowledge=db('knowledge')->where('section_num',$section_num)->delete();
                            if($chapter){
                                $this->success('删除成功',url('Column/chapter?id='.$grade[0]['id']));
                            }else{
                                $this->error('删除失败');
                            }
                     
                            
                        }
                    
                        }                   
    



            // 节
              public function section(){
                if(request()->isGet()){
                    $id=\think\Request::instance()->param('id');
                    // dump($id);die;
                    $chapter=\think\Db::query('select * from sxz_chapter where id='.$id);
                    // dump($chapter);die;
                    $grade = \think\Db::query('select * from sxz_grade where grade_num='.$chapter[0]['grade_num']);
                    // dump($grade);die;
                    $edition = \think\Db::query('select * from sxz_edition where edi_num='.$grade[0]['edi_num']);
                    // dump($edition);die;
                    $stage = \think\Db::query('select * from sxz_stage where sta_sub='.$edition[0]['sta_sub']);
                    // dump($stage);die;
                    $section=\think\Db::query('select * from sxz_section where chap_num='.$chapter[0]['chap_num']);
                    // dump($edition);die;
                    $this->assign('section',$section);
                    $this->assign('chapter',$chapter);
                    $this->assign('grade',$grade);
                    $this->assign('stage',$stage);
                    $this->assign('edition',$edition);
                    return view();
             
                }              
                
                
                 }
            
                     // 添加
                     public function sectionadd(){
                        if(request()->isPost()){
                            $chap_num=\think\Request::instance()->param('chap_num');

                            $section_num=new Section();
                            $section_num=$section_num->section_num();
                            
                            $section_num=$section_num[0]['max(section_num)'];
                            $section_num=$section_num+1;
                            // dump($section_num);die;
            
                            $data=[
                                'chap_num'=>input('chap_num'),
                                'section_name'=>input('section_name'),
                                'section_num'=>$section_num,
                            ];
                            // dump($data);die;
                            $section=db('section')->insert($data);
                            // 
                            $chapter=\think\Db::query('select * from sxz_chapter where chap_num='.$chap_num);
                            if($section ){
                                $this->success('添加成功',url('Column/section?id='.$chapter[0]['id']));
                            }else{
                                $this->error('添加失败');
                            }
                     
                            
                        }
                    
                        }
                        // 修改
                        public function sectionedit(){
                            if(request()->isPost()){
                                $id=\think\Request::instance()->param('id');
                                // dump($id);die;
                                $section=\think\Db::query('select * from sxz_section where id='.$id);
                                // dump($knowledge);die;

                                $chap_num=$section[0]['chap_num'];
                                $chapter=\think\Db::query('select * from sxz_chapter where chap_num='.$chap_num);
                                // dump($section);die;
                                $data=[
                                    'section_name'=>input('section_name'),
                                ];                                                                       
                                $section=db('section')->where('id',$id)->update($data);                                       
                                if($section ){
                                    $this->success('修改成功',url('Column/section?id='.$chapter[0]['id']));
                                }else{
                                    $this->error('修改失败');
                                }
                                                       
                            }
                        
                            }


                        
                          // 删除
                     public function sectiondel(){
                        if(request()->isGet()){
                            $id=\think\Request::instance()->param('id');
                            // dump($id);die;
                            $section=\think\Db::query('select * from sxz_section where id='.$id);
                            // dump($section);die;
                            $chap_num=$section[0]['chap_num'];

                            $chapter=\think\Db::query('select * from sxz_chapter where chap_num='.$chap_num);
                            
                            $section_num=$section[0]['section_num'];
                            $section=db('section')->where('id',$id)->delete();
                            $knowledge=db('knowledge')->where('section_num',$section_num)->delete();
                            if($section){
                                $this->success('删除成功',url('Column/section?id='.$chapter[0]['id']));
                            }else{
                                $this->error('删除失败');
                            }
                     
                            
                        }
                    
                        }


                // 知识点
              public function knowledge(){
                if(request()->isGet()){
                    $id=\think\Request::instance()->param('id');
                    // dump($id);die;
                   
                    $section=\think\Db::query('select * from sxz_section where id='.$id);
                    // dump($section);die;
                    $chapter=\think\Db::query('select * from sxz_chapter where chap_num='.$section[0]['chap_num']);
                    // dump($chapter);die;
                    $grade = \think\Db::query('select * from sxz_grade where grade_num='.$chapter[0]['grade_num']);
                    // dump($grade);die;
                    $edition = \think\Db::query('select * from sxz_edition where edi_num='.$grade[0]['edi_num']);
                    // dump($edition);die;
                    $stage = \think\Db::query('select * from sxz_stage where sta_sub='.$edition[0]['sta_sub']);
                    // dump($stage);die;
                    $knowledge=\think\Db::query('select * from sxz_knowledge where section_num='.$section[0]['section_num']);
                    // dump($edition);die;
                    $this->assign('knowledge',$knowledge);
                    $this->assign('section',$section);
                    $this->assign('chapter',$chapter);
                    $this->assign('grade',$grade);
                    $this->assign('stage',$stage);
                    $this->assign('edition',$edition);
                    return view();
             
                }              
                
                
                 }
                     // 添加
                     public function knowledgeadd(){
                        if(request()->isPost()){
                            $section_num=\think\Request::instance()->param('section_num');
                            
                            $know_num=new Knowledge();
                            $know_num=$know_num->know_num();
                            $know_num=$know_num[0]['max(know_num)'];
                            $know_num=$know_num+1;
                            // dump($section_num);die;
                            // dump($know_num);die;
                            $data=[
                                'section_num'=>input('section_num'),
                                'know_name'=>input('know_name'),
                                'know_num'=>$know_num,
                               
                            ];
                            // dump($data);die;
                            $knowledge=db('knowledge')->insert($data);
                            // 
                            $section=\think\Db::query('select * from sxz_section where section_num='.$section_num);
                            // dump($section);die;
                            if($knowledge ){
                                $this->success('添加成功',url('Column/knowledge?id='.$section[0]['id']));
                            }else{
                                $this->error('添加失败');
                            }
                     
                            
                        }
                    
                        }
                        // 修改
                        public function knowledgeedit(){
                            
                           
                            if(request()->isPost()){
                                $id=\think\Request::instance()->param('id');
                                
                                //   dump($id);die;

                                $knowledge=\think\Db::query('select * from sxz_knowledge where id='.$id);
                                // dump($knowledge);die;

                                $section_num=$knowledge[0]['section_num'];
                                $section=\think\Db::query('select * from sxz_section where section_num='.$section_num);
                                // dump($section);die;
    
                                $data=[
                                    'know_name'=>input('know_name'),
                                ]; 
                                // dump($data); die;                                                                     
                                $knowledge=db('knowledge')->where('id',$id)->update($data);                                  
                                //   dump($knowledge);die;  
                                if($knowledge){
                                    $this->success('修改成功',url('Column/knowledge?id='.$section[0]['id']));
                                }else{
                                    $this->error('修改失败');
                                }
                                                       
                            }
                        
                            }

                          // 删除
                     public function knowledgedel(){
                        if(request()->isGet()){
                            $id=\think\Request::instance()->param('id');
                            // dump($id);die;
                            $knowledge=\think\Db::query('select * from sxz_knowledge where id='.$id);
                            // dump($knowledge);die;
                            $section_num=$knowledge[0]['section_num'];
                            $section=\think\Db::query('select * from sxz_section where section_num='.$section_num);
                            // dump($section);die;
                            $knowledge=db('knowledge')->where('id',$id)->delete();

                            if($knowledge ){
                                $this->success('删除成功',url('Column/knowledge?id='.$section[0]['id']));
                            }else{
                                $this->error('删除失败');
                            }
                     
                            
                        }
                    
                        }
                        
                
        






















}