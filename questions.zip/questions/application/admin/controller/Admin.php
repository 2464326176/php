<?php
namespace app\admin\controller;
use think\Controller;
Class Admin extends Common
{
    // 输出
    public function index(){
        if(request()->isPost()){
            $search=\think\Request::instance()->param('search');
            // dump($search);
            $search= \think\Db::name('admin')->alias('a')->join('admingroup b','a.levelname=b.group_id')->where('username|nickname|loginip|groupname','like',"%$search%")->select();
            // dump($search);die;
            if($search){
                 $this->assign('data',$search);
                return view();
            }else{
               $this->error('未查询到相关内容'); 
            }
           
        }else{
            $data= \think\Db::name('admin')->alias('a')->join('admingroup b','a.levelname=b.group_id')->select();
            $this->assign('data',$data);
            
            return view();
        }

           
    }
  
    public function ajaxpwd(){
       if (\think\Request::instance()->isAjax()){
            
            $id=\think\Request::instance()->param('id');
            $password=\think\Request::instance()->param('password');
            $data= \think\Db::name('admin')->where('id',$id)->find();
            if($data['password']==$password){
                return ['info'=>'操作成功'];
            }else{
                // $this->error('错误');
            }          
        }else{
            // $this->error('错误');
        }      
    }
    // 添加
    public function add()
    {
        if(request()->isPost()){
            // echo "ok"; die;
            $data=[
                'username'=>input('username'),
                'password'=>input('password'),
                'nickname'=>input('nickname'),
                'checkadmin'=>input('checkadmin'),
                'levelname'=>input('levelname'),
            ];
            $validate = \think\Loader::validate('Admin');
            if(!$validate->check($data)){
                return $this->error($validate->getError());
            }else{
                $data= \think\Db::name('admin')->insert($data);
            // dump($data);die;
                if($data){
                    return $this->success('添加成功');
                }else{
                return $this->error('添加失败');
                }
            }
            return;
        }else{

            $data= \think\Db::name('admingroup')->select();
            $this->assign('data',$data);         
            return view();
        }
        
    }
    //修改
    public function mod(){
        if(request()->isGet()){
            $id=\think\Request::instance()->param('id');
            // dump($id);die;
         
            $data=\think\Db::query('select * from sxz_admin where id ='.$id);
            
            $admingroup=\think\Db::query('select * from sxz_admingroup');
            
            $this->assign('admingroup',$admingroup);
            $this->assign('data',$data);
            return view('modify'); 
    }else{
         return $this->error('参数错误');
    }
    }
    
    public function modify(){    
            if(request()->isPost()){
            $id=\think\Request::instance()->param('id');
            // dump($id);die;
            if(empty(input('oldpassword'))){
                // dump('ok');die;
                $data=[
                'username'=>input('username'),
                'nickname'=>input('nickname'),
                'checkadmin'=>input('checkadmin'),
                'levelname'=>input('levelname'),
            ];
            }else{
                $data=[
                'username'=>input('username'),
                'nickname'=>input('nickname'),
                'password'=>input('password'),
                'checkadmin'=>input('checkadmin'),
                'levelname'=>input('levelname'),
            ];
            }    
            // dump($data);dump($id);
            // $data = \think\Db::name('admin')->where('id',$id)->update($data);
            $data=db('admin')->where('id',$id)->update($data);
            // dump($data);die;
            if($data){
                $this->success('修改成功',url('Admin/index'));
            }else{
                $this->error('修改失败');
            }
            
            }else{
                $this->error('参数错误');
            }
    }



    // 单个删除
    public function delete(){
        if(request()->isGet()){

        $delete=db('admin')->delete(input('id'));
        if($delete){
            $this->success('删除成功！',url('index'));
        }else{
            $this->error('删除失败！');
        }

        }else{
            $this->error('参数错误！');
        }
        
    }
    // 多个删除
    public function del(){
        if(request()->isPost()){
        $id=input('post.id/a');
        $id_v=implode(',',$id);
        // dump($id_v);  die;
        $delete=db('admin')->delete($id_v);
        if($delete){
            $this->success('删除成功！',url('index'));
        }else{
            $this->error('删除失败！');
        }

        }else{
            $this->error('参数错误！');
        }
        
    }
    
}
