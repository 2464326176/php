<?php
namespace app\admin\controller;
use think\Controller;
Class Common extends Controller
{
    public function _initialize()
    {
        if(!session('id') || !session('username')){
           $this->error('您尚未登录系统',url('login/index')); 
        }
    }
    
}

