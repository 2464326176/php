<?php
namespace app\admin\controller;
use think\Controller;
Class About extends Common
{
    public function index(){
       
        if(request()->isPost()){
            $id=\think\Request::instance()->param('id');
            // dump($id);die;
             $data=[
                
                'content'=>input('content'),
            ];
            // dump($data);die;
             $data=db('about')->where('id',$id)->update($data);
            if($data){
                $this->success('修改成功',url('About/index'));
            }else{
                $this->error('修改失败');
            }
     
        }else{
             
            $data= \think\Db::name('about')->select();
            $this->assign('data',$data);
            return view();

        }
    }

 
















}