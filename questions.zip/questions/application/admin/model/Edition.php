<?php
namespace app\admin\model;
use think\Model;
class Edition extends Model
{


    public function edi_num(){

        $result = \think\Db::query('select max(edi_num) from sxz_edition');
        
        return $result;
        

    }



    }






