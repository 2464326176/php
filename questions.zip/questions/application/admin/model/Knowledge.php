<?php
namespace app\admin\model;
use think\Model;
class Knowledge extends Model
{

    public function know_num(){

        $result = \think\Db::query('select max(know_num) from sxz_knowledge');
        
        return $result;
        

    }



    }






