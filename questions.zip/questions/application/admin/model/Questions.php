<?php
namespace app\admin\model;
use think\Model;
class Questions extends Model
{


    public function ques_num(){

        $result = \think\Db::query('select max(ques_num) from sxz_questions');
        
        return $result;
        

    }



    }






