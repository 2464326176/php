<?php
namespace app\admin\model;
use think\Model;
class Section extends Model
{


    public function section_num(){

        $result = \think\Db::query('select max(section_num) from sxz_section');
        
        return $result;
        

    }



    }






