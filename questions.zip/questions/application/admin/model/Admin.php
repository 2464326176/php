<?php
namespace app\admin\model;
use think\Model;
class Admin extends Model
{

   
    public function login($data){
       
        
        $admin= \think\Db::name('admin')->alias('a')->join('admingroup b','a.levelname=b.group_id')->where('username',$data['username'])->find();
        // dump($admin);
        if($admin){
            if($admin['checkadmin']=='true'){
                 if($admin['password']==md5($data['password'])){
               
                $data = [
                    'loginip' =>request()->ip(),
                    'logintime' => time(), 
                ];
                
                $data=db('admin')->where('id',$admin['id'])->update($data);
                session('id', $admin['id']);
                session('username', $admin['username']);
                session('nickname', $admin['nickname']);
                session('groupname', $admin['groupname']);
                
                return 2; //登录密码正确的情况
            }else{
                return 3; //登录密码错误
            }
            }else{
                return 4;
            }
           
        }else{
            return 1; //用户不存在的情况
        }

    }






}
