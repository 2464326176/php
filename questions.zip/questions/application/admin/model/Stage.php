<?php
namespace app\admin\model;
use think\Model;
class Stage extends Model
{


    public function sta_sub(){

        $result = \think\Db::query('select max(sta_sub) from sxz_stage');
        
        return $result;
        

    }

  



    }






