<?php
namespace app\admin\model;
use think\Model;
class Grade extends Model
{

    public function grade_num(){

        $result = \think\Db::query('select max(grade_num) from sxz_grade');
        
        return $result;
        

    }



    }






