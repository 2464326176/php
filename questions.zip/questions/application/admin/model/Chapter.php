<?php
namespace app\admin\model;
use think\Model;
class Chapter extends Model
{


    public function chap_num(){

        $result = \think\Db::query('select max(chap_num) from sxz_chapter');
        
        return $result;
        

    }



    }






