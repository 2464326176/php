<?php
namespace app\admin\model;
use think\Model;
class Topic extends Model
{


    public function topic_num(){

        $result = \think\Db::query('select max(topic_num) from sxz_topic');
        
        return $result;
        

    }



    }






