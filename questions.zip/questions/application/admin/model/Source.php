<?php
namespace app\admin\model;
use think\Model;
class Source extends Model
{


    public function source_num(){

        $result = \think\Db::query('select max(source_num) from sxz_source');
        
        return $result;
        

    }



    }






