<?php
namespace app\admin\model;
use think\Model;
class Difficulty extends Model
{


    public function diff_num(){

        $result = \think\Db::query('select max(diff_num) from sxz_difficulty');
        
        return $result;
        

    }



    }






