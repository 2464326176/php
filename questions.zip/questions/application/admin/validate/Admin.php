<?php
namespace app\admin\validate;
use think\Validate;
class Admin extends Validate
{
    protected $rule = [
        'username'  =>  'require|max:11',
        'username'   => 'unique:admin',

    ];
    protected $message  =   [
        'username.require' => '账号不能为空',
        'username.unique'=>'账号不能重复',
        'nickname.require' => '名字不能为空',
        'password.require' => '密码不能为空',   
    ];

}













