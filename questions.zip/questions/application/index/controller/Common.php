<?php
namespace app\index\controller;
use think\Controller;
Class Common extends Controller
{

    public function header(){

        return view();
    }
    public function footer(){
        return view(); 
    }
    public function tool(){
    
   
        return view(); 
    }


















}