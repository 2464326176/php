<?php
namespace app\index\controller;
use think\Controller;
Class Index extends Controller
{
//
        // 首页面
    public function index()
    {
        // 网站开关
        $webconfig=\think\Db::name('webconfig')->where('id',1)->find();      
    	if($webconfig['switch']=='true'){
            $content=\think\Db::name('content')->select();
            $this->assign('content',$content);
            return view();
    	}else{
            return htmlspecialchars_decode($webconfig['switchshow']);

    	}     
    }



//     public function tree()
//     {
//         // 网站开关
//         $webconfig=\think\Db::name('webconfig')->where('id',1)->find();      
//     	if($webconfig['switch']=='true'){
//                 $chapter=\think\Db::query('select * from sxz_chapter');
//                 $section=\think\Db::query('select * from sxz_section');
//                 $knowledge=\think\Db::query('select * from sxz_knowledge');
                
//                 $this->assign('chapter',$chapter);
//                 $this->assign('section',$section);
//                 $this->assign('knowledge',$knowledge);
            
//             return view();
//     	}else{
//             return htmlspecialchars_decode($webconfig['switchshow']);

//     	}     
//     }
   
}

