function childAddedCbk(~,~)

function manageButtons(~,~,~)
