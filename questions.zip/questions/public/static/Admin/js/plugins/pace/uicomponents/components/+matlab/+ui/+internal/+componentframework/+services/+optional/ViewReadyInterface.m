% VIEWREADYINTERFACE is an interface which provides information about the 
% readiness of the view for those who exercise it. 
%
% Copyright 2015 The MathWorks, Inc.
classdef (Abstract)  ViewReadyInterface < handle
end
