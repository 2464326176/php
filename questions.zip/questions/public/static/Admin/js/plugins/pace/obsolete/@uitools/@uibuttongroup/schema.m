function schema()
pkg   = findpackage('uitools');
h = schema.class(pkg, 'uibuttongroup');
