function schema

schema.package('uitools');
