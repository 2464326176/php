classdef DesignTimeGBTLeafController < matlab.ui.internal.DesignTimeGbtParentingController
    % DESIGNTIMEGBTNONPARENTINGCONTROLLER is a design time controller with 
    % non-container features. 
    
    % Copyright 2015 The MathWorks, Inc.    
    
    % @ToDo
    % Short-term solution for table, which is the first leaf design-time
    % controller.
    % NoOp all parenting functions.
    % Need to refactor to the base controller class once we integrate all
    % container controllers (figure and buttongroup). 
    
    methods (Access=protected)             
        function deleteChild(obj,model,child)
            % NoOp for leaf controller
        end 
    end

end