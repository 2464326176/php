% CONTROLLERINTERFACE MATLAB Component Framework's (MCF) interface  
% provides access to the web-based controller of the web component.
% 
% Copyright 2014 The MathWorks, Inc.
classdef (Abstract, Hidden)  ControllerInterface < handle
end
