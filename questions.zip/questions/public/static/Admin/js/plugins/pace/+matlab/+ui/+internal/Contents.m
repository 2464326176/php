% An internal package contains function code that is intended for MathWorks
% use only. The package is implemented by a directory named +internal.

%   Copyright 2010 The MathWorks, Inc.
