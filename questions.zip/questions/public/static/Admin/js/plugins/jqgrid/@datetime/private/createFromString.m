function adata = createFromString(dateStrings, dateFormat, errMode, timeZone, locale, pivotYear)

%   Copyright 2015 The MathWorks, Inc.

numIn = nargin;
if numIn == 6 % most common syntax
    adata = builtin('_createFromString',dateStrings,dateFormat,errMode,timeZone,locale,pivotYear);        
elseif numIn == 4
    adata = builtin('_createFromString',dateStrings,dateFormat,errMode,timeZone);
else % least common syntax
    adata = builtin('_createFromString',dateStrings,dateFormat,errMode,timeZone,locale);
end
