function tf = issorted(this,varargin)
%ISSORTED True for sorted durations vectors and matrices.
%   TF = ISSORTED(A), when A is a vector of durations, returns logical 1 (true)
%   if the elements of A are in sorted order (in other words, if A and SORT(A)
%   are identical) and logical 0 (false) if not.
%   
%   TF = ISSORTED(A,'rows'), when A is a matrix of durations, returns logical 1
%   (true) if the rows of A are in sorted order (if A and SORTROWS(A) are
%   identical) and logical 0 (false) if not.
%   
%   If A is sorted, NAN elements appear at the end.
%   
%   See also SORT, SORTROWS.

%   Copyright 2014 The MathWorks, Inc.

tf = issorted(this.millis,varargin{:});
