function cdata = datetimeSubtract(adata, bdata, fullPrecision)

%   Copyright 2015 The MathWorks, Inc.

if nargin == 2
    cdata = builtin('_datetimeSubtract', adata, bdata);
else
    cdata = builtin('_datetimeSubtract', adata, bdata, fullPrecision);
end
