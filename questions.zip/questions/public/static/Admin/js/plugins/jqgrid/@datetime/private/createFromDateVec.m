function adata = createFromDateVec(dateVec, timeZone)

%   Copyright 2015 The MathWorks, Inc.

adata = builtin('_createFromDateVec', dateVec, timeZone);
