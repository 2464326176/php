function fmt = verifyFormat(fmt)

%   Copyright 2014 The MathWorks, Inc.

import matlab.internal.tableUtils.isstring

try

    if isstring(fmt)
        try % try out the format, ignore any return value
            formatAsString(1234.56789,fmt,false);
        catch ME
            error(message('MATLAB:duration:UnrecognizedFormat',fmt));
        end
    else
        error(message('MATLAB:duration:InvalidFormat'));
    end

catch ME
    throwAsCaller(ME);
end
