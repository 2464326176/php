function names = getMonthNames(format, locale)

%   Copyright 2015 The MathWorks, Inc.

if nargin == 1
    names = builtin('_getMonthNames',format);
else
    names = builtin('_getMonthNames',format,locale);
end
