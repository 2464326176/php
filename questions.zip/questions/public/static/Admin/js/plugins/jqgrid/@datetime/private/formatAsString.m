function dateStrings = formatAsString(adata, dateFormat, timeZone, locale)

%   Copyright 2015 The MathWorks, Inc.

if nargin == 3
    dateStrings = builtin('_datetimeFormatAsString',adata,dateFormat,timeZone);
else
    dateStrings = builtin('_datetimeFormatAsString',adata,dateFormat,timeZone,locale);
end
