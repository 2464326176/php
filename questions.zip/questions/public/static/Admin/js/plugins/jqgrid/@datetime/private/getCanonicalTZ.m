function [canonID,offset] = getCanonicalTZ(timeZone, doWarn, localTimeZone)

%   Copyright 2015 The MathWorks, Inc.

numIn = nargin;
if numIn == 3 % most common syntax
    [canonID,offset] = builtin('_getCanonicalTZ',timeZone,doWarn,localTimeZone);
elseif numIn == 2
    [canonID,offset] = builtin('_getCanonicalTZ',timeZone,doWarn);
else % least common syntax
    [canonID,offset] = builtin('_getCanonicalTZ',timeZone);
end
