function names = getDayNames(format, locale)

%   Copyright 2015 The MathWorks, Inc.

if nargin == 1
    names = builtin('_getDayNames',format);
else
    names = builtin('_getDayNames',format,locale);
end
