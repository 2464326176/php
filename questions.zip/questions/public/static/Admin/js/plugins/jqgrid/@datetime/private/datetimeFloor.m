function bdata = datetimeFloor(adata, timeUnit, timeZone)

%   Copyright 2015 The MathWorks, Inc.

bdata = builtin('_datetimeFloor', adata, timeUnit, timeZone);
