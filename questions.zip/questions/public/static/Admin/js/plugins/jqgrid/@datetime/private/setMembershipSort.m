function [data,i,j,reord] = setMembershipSort(data,i,j,rows)

%   Copyright 2014 The MathWorks, Inc.

if nargin == 2
    rows = i;
elseif nargin == 3
    rows = j;
end

if rows
    [data,reord] = datetimeSortrows(data);
else
    [data,reord] = datetimeSort(data);
end

if nargin == 2 % [data,reord] = setMembershipSort(data,rows)
    i = reord;
elseif nargin == 3 % [data,i,reord] = setMembershipSort(data,i,rows)
    i(:) = i(reord);
    j = reord;
else % [data,i,j,reord] = setMembershipSort(data,i,j,rows)
    i(:) = i(reord);
    j(:) = j(reord);
end
