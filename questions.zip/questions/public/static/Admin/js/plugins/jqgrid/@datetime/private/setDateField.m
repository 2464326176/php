function bdata = setDateField(adata, values, fieldID, timeZone)

%   Copyright 2015 The MathWorks, Inc.

bdata = builtin('_setDateField', adata, values, fieldID, timeZone);
