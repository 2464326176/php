function throwInstead(ME,oldMsgID,newMsg)

%   Copyright 2014-2015 The MathWorks, Inc.

% If the exception is one of the specified errors, throw the desired one instead
if any(strcmp(ME.identifier,oldMsgID))
    error(newMsg);
else
    rethrow(ME);
end

