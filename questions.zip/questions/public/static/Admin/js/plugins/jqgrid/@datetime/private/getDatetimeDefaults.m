function defaultVal = getDatetimeDefaults(dateTimeAttribute, locale, skeleton)

%   Copyright 2015 The MathWorks, Inc.

if nargin == 1 % 'timezone', 'locale', 'pivotyear'
    defaultVal  = builtin('_getDatetimeDefaults',dateTimeAttribute);
else
    defaultVal  = builtin('_getDatetimeDefaults',dateTimeAttribute,locale,skeleton);
end
