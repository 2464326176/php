function bdata = datetimeMean(adata,dim,omitnan)

%   Copyright 2014-2015 The MathWorks, Inc.

if nargin == 3
    bdata = builtin('_datetimeMean',adata,dim,omitnan);
else % provide 2-input case datetimeMean(adata, omitnan)
    bdata = builtin('_datetimeMean',adata,dim);
end

