function durationStrings = formatAsString(durations,durationFormat,isLong,locale)
if nargin==3
    durationStrings = builtin('_durationFormatAsString',durations,durationFormat,isLong);
else
    durationStrings = builtin('_durationFormatAsString',durations,durationFormat,isLong,locale);
end