function [bdata,i] = datetimeSortrows(adata,col)

%   Copyright 2014 The MathWorks, Inc.

if nargin < 2
    col = 1:size(adata,2);
end

[~,j] = sortrows(imag(adata),col);
[~,k] = sortrows(real(adata(j,:)),col);
i = j(k);

bdata = adata(i,:);
