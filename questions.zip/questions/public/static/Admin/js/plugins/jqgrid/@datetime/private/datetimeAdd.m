function cdata = datetimeAdd(adata, bdata)

%   Copyright 2015 The MathWorks, Inc.

cdata = builtin('_datetimeAdd', adata, bdata);
