function bdata = addToDateField(adata, amounts, fieldID, timeZone)

%   Copyright 2015 The MathWorks, Inc.

bdata = builtin('_addToDateField',adata,amounts,fieldID,timeZone);
