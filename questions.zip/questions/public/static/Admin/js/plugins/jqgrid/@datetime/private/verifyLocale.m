function validatedLocale = verifyLocale(locale)

%   Copyright 2015 The MathWorks, Inc.

validatedLocale = builtin('_verifyLocale',locale);
